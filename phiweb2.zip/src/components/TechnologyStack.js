import React from 'react';
import './CoreTechnologyStack.css';

const TechnologyStack = () => {
  return (
    <div className="core-technology-container">
      <div className="header-section">
        <h1>Core Technology Stack</h1>
        <p>The Neurocortex platform is built upon and deeply integrated with NVIDIA's end-to-end robotics platform.</p>
      </div>
      <div className="cards-grid">
        <div className="card">
          <div className="card-image-container">
            <img src="/images/Jetson thor.png" alt="Logo" className="card-image" />
          </div>
          <div className="card-content">
            <h2 className="card-title">Logo</h2>
            <p className="card-description">
              Provides the high-performance, onboard compute necessary to run the entire Neurocortex stack in real-time.
            </p>
          </div>
        </div>

        <div className="card">
          <div className="card-image-container">
            <img src="/images/isaacsim.png" alt="Problem" className="card-image" />
          </div>
          <div className="card-content">
            <h2 className="card-title">Problem</h2>
            <p className="card-description">
              Used extensively for training the Cognitive Engine's learning models in a physically accurate and scalable virtual environment.
            </p>
          </div>
        </div>

        <div className="card">
          <div className="card-image-container">
            <img src="/images/isaacperceptor.png" alt="Çözüm" className="card-image" />
          </div>
          <div className="card-content">
            <h2 className="card-title">Çözüm</h2>
            <p className="card-description">
              Provides foundational libraries for 3D perception, sensor fusion, and SLAM, leveraged by the Perception Engine.
            </p>
          </div>
        </div>

        <div className="card">
          <div className="card-image-container">
            <img src="/images/icon-2.png" alt="High Level" className="card-image" />
          </div>
          <div className="card-content">
            <h2 className="card-title">High Level</h2>
            <p className="card-description">
              Provides the baseline motor skills and physical interaction capabilities upon which the Action Generation Engine builds.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechnologyStack; 