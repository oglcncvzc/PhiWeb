import React from 'react';
import './Neurocortex.css';
import NeurocortexGraphic from './NeurocortexGraphic';

const Neurocortex = () => {
  const cards = [
    {
      icon: '/images/icon.png',
      title: 'Çok Modlu Anlayış',
      description: 'Dil, görüntü ve sensör verilerini birleştirerek bütünsel bir dünya modeli oluşturur.'
    },
    {
      icon: '/images/anındaogrenme.png',
      title: 'Anında Öğrenme',
      description: 'Yeni görevleri tek bir gösterimle veya sözlü komutla öğrenme yeteneği kazanır.'
    },
    {
      icon: '/images/nedenselakıl.png',
      title: 'Nedensel Akıl Yürütme',
      description: 'Eylemlerinin sonuçlarını tahmin eder ve karmaşık problemleri çözmek için planlama yapar.'
    }
  ];

  return (
    <section className="neurocortex" id="cozum">
      <div className="container">
        <h2 className="section-title">Neurocortex - Bilişsel Çekirdek</h2>
        
        <NeurocortexGraphic />

        <div className="neurocortex-description">
          <p>
            Neurocortex, NVIDIA GrOOT için tasarlanmış devrim niteliğinde bir yazılım katmanıdır. Gelişmiş çok modlu öğrenme yeteneklerini ve geniş bir bilgi tabanını, GrOOT'un fiziksel becerileriyle entegre ederek robotlara benzeri görülmemiş bir bilişsel derinlik kazandırır.
          </p>
          <p>
            Robotlarımız sadece <strong>'ne yapacaklarını'</strong> değil, aynı zamanda <strong>'neden'</strong> yaptıklarını da anlarlar. Bu, daha güvenli, daha verimli ve daha uyumlu otonom sistemlerin kapısını aralar!
          </p>
        </div>

        <div className="cards-grid">
          {cards.map((card, index) => (
            <div key={index} className="card">
              <div className="card-icon">
                <img src={card.icon} alt={card.title} />
              </div>
              <h3 className="card-title">{card.title}</h3>
              <p className="card-description">{card.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Neurocortex; 